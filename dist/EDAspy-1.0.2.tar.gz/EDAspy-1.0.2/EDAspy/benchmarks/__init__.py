#!/usr/bin/env python
# coding: utf-8

# __init__.py

from .binary import *
from .continuous import ContinuousBenchmarkingCEC14
