#!/usr/bin/env python
# coding: utf-8

# __init__.py

__version__ = '1.1.2'
