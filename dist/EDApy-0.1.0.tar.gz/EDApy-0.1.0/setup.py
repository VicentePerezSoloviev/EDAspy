import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="EDApy",
    version="0.1.0",
    author="Vicente P. Soloviev",
    author_email="vicente.perez.soloviev@gmail.com",
    description="This is a package where some estimation of distribution algorithms are implemented.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    download_url="https://github.com/VicentePerezSoloviev/EDApy/archive/0.1.0.tar.gz",
    url="https://github.com/VicentePerezSoloviev/EDApy",
    packages=setuptools.find_packages(),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: LGPL-2.1",
        "Operating System :: OS Independent",
    ],
    keywords=['EDA', 'estimation', 'bayesian', 'evolutionary', 'algorithm', 'optimization'],
    python_requires='>=3.6',
    license="LGPL-2.1",
)
