#!/usr/bin/env python
# coding: utf-8

# __init__.py

from .binary import one_max
from .continuous import ContinuousBenchmarkingCEC14
